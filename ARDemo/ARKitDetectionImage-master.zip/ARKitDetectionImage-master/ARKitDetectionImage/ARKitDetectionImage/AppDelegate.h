//
//  AppDelegate.h
//  ARKitDetectionImage
//
//  Created by LJP on 2018/4/2.
//  Copyright © 2018年 LJP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

